import DevHero from './DevHero.jsx';
import Devinfo from './Devinfo.jsx';
import React,{useState} from 'react';
function Features(){
    return(
       <>
       <Devinfo/>
       </>
    );
}
export default Features 

