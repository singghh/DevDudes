import React from 'react';
import Discord from "../assets/devdudesimgs/discord_image.png";
import Question from "../assets/devdudesimgs/ques.jpg";
import Linkedimg from "../assets/devdudesimgs/linkedimg.png"
import Limage from "../assets/devdudesimgs/profilepic.jpg";
import L2image from "../assets/devdudesimgs/varunimg.jpeg";
function Joinus(){
    const linkedinmenu = [
        {
            id:1,
            title:"A Sai charan",
            link:"https://www.linkedin.com/in/a-sai-charan-166573259/",
            image: Limage
        },
        {
            id:2,
            title:"Bamla Varun Singh",
            link:"https://www.linkedin.com/in/bamla-varun-singh-b05245259/",
            image:L2image
        }
    ]
    return(
        <>
        <div className='mt-36 md:mt-0'>
            <div className="bg-[#2b3f81] text-white rounded-lg p-4 max-w-sm mx-auto">
                    <div className="flex items-center space-x-4">
                        <div >
                        <a href="https://discord.gg/TB2yM6RF"><img 
                        className="w-20 h-20 cursor-pointer hover:scale-110"
                        src={Discord} 
                        alt="Discord Logo" 
                        /></a>
                        </div>
                        <div className="flex flex-col">
                        <h2 className="text-lg font-semibold font-mono">What to get updates ?</h2>
                        <a href="https://discord.gg/TB2yM6RF" className="text-lg text-center font-semibold font-mono cursor-pointer hover:underline"> Join our Community</a>
                        </div>
                    </div>
                </div>
                <br />
                <div className=' '>
                        <div className='bg-blue-950 flex justify-center gap-5 items-center'>
                            <div className='text-white'>
                                <h1 className='text-2xl'>Any queries</h1>
                            </div>
                            <img className="rounded-full w-24" src={Question} alt="" />
                            <div className='text-white text-2xl'>
                                Reach out to us
                            </div>
                        </div>
                    </div>
                    <br />
                    <div className='bg-[#122355] rounded-lg p-4 max-w-xl mx-auto'>
                        <ul className="flex justify-between text-lg space-x-8">
                            {linkedinmenu.map((menu)=>(
                                <li key={menu.id} className='text-center items-center justify-center'>
                                    <div className='rounded-2xl p-4 shadow-2xl justify-center items-center'>
                                    <img className='w-20 ml-14 rounded-full' src={menu.image} alt="" />
                                    <a target="_blank" className="text-white text-xl"> {menu.title}</a>
                                    <a href={menu.link} target="_blank" className="flex items-center text-blue-500 ">
                                        <img src={Linkedimg} alt="LinkedIn" className="w-6 h-6 mr-2" />
                                            Connect on LinkedIn
                                    </a>
                                    
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <br />
                    <div className='h-10 bg-[#122355]'>
                        <h1 className='text-white text-center font-mono text-2xl'>Follow us</h1>
                    </div>
                    
                </div>
            </>
    );
}
export default Joinus